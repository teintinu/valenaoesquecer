(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/enviohistoria.js                                             //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
historias = new Mongo.Collection("historias");                         // 1
                                                                       //
Meteor.methods({                                                       // 3
  envioHistoria: function (userId, local, link, texto) {               // 4
    if (userId != this.userId) return;                                 // 5
                                                                       //
    var user = Meteor.users.findOne({ _id: userId });                  // 8
                                                                       //
    console.dir(user);                                                 // 10
                                                                       //
    if (!user.profile || user.profile.bloqueio > new Date().getTime()) return "Você precisa esperar pelo menos uma hora pra enviar outra história";
                                                                       //
    var fb = user.services.facebook;                                   // 15
                                                                       //
    historias.insert({                                                 // 17
      userId: userId,                                                  // 18
      local: local,                                                    // 19
      link: link,                                                      // 20
      texto: texto,                                                    // 21
      envio: new Date(),                                               // 22
      verificado: false                                                // 23
    });                                                                //
                                                                       //
    Meteor.users.update({ _id: userId }, {                             // 26
      $set: {                                                          // 27
        "profile.bloqueio": new Date().getTime() + 1000 * 60 * 60      // 28
      }                                                                //
    });                                                                //
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=enviohistoria.js.map
